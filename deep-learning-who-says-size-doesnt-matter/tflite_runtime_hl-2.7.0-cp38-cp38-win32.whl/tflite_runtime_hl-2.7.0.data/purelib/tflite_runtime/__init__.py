__version__ = '2.7.0'
__git_version__ = '0.6.0-118178-gc256c071bb2'
